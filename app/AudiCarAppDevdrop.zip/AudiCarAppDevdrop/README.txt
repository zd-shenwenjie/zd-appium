1. Kopieren der aller *.json im Ordner "config" nach "sdcard/etc/eso"
2. Installieren der ViwiBridge.apk und AudiCar.apk
3. Permission "Storage" f�r beide Apps vor dem Starten aktivieren


- bei �nderungen an den config-Dateien muss die ViwiBridge-App mit force-stop beendet und danach neu gestartet werden
- zugriff auf das mock-rsi im emulator erfolgt durch "adb forward tcp:14712 tcp:14712" danach l�sst sich �ber localhost:14712 das rsi wie gewohnt anzeigen


